const { onCall } = require("firebase-functions/v2/https");
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.firestore();

exports.createUserProfile = onCall(async (request) => {
  if (!request.auth) throw new Error("Authentication required");
  const uid = request.auth.uid;
  const ref = db.collection("users").doc(uid);
  const snap = await ref.get();
  if (!snap.exists) {
    await ref.set({
      uid,
      displayName: request.auth.token.name || "DailyHub User",
      email: request.auth.token.email || null,
      walletBalance: 0,
      referralCode: "DH-" + uid.substring(0, 8).toUpperCase(),
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
  }
  return {ok: true};
});

exports.createCommission = onDocumentCreated("transactions/{id}", async (event) => {
  const data = event.data?.data();
  if (!data || data.status !== "SUCCESS") return;
  const amount = Number(data.commission || 0);
  if (amount <= 0) return;
  await db.collection("commissions").add({
    transactionId: event.params.id,
    userId: data.userId || null,
    service: data.service || "unknown",
    amount,
    status: "PENDING",
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
});
